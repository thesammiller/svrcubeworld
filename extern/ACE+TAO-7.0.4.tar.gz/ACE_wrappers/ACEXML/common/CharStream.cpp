// -*- C++ -*-

#include "ACEXML/common/CharStream.h"

ACEXML_CharStream::~ACEXML_CharStream (void)
{
}
